variable "cluster_name" {
  type = string
  default = "corp-k8s-prod"
}
