output "cluster_endpoint" {
  value = "https://k8s-api.corp.internal"
}
