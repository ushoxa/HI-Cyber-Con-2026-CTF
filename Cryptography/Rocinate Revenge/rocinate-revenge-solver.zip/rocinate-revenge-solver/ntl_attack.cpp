#include "disk_poly.hpp"

struct Term {ZZ offset;long exponent;};
ZZ_pX product_tree(const std::vector<Term>& terms,const fs::path& prefix){
    fs::path checkpoint=prefix.string()+".bin";
    if(fs::exists(checkpoint)){std::cout<<"Load "<<checkpoint<<std::endl;return read_poly(checkpoint);}
    ZZ_pX result;
    if(terms.empty())set(result);
    else if(terms.size()==1){ZZ_pX base;SetCoeff(base,0,conv<ZZ_p>(terms[0].offset));SetCoeff(base,1,1);result=safe_power(base,terms[0].exponent);}
    else{
        std::vector<Term> left,right;long ld=0,rd=0;
        for(const auto& term:terms){if(ld<=rd){left.push_back(term);ld+=term.exponent;}else{right.push_back(term);rd+=term.exponent;}}
        fs::path lp=prefix.string()+"0",rp=prefix.string()+"1";
        if(ld+rd>12000000){
            if(!fs::exists(lp.string()+".bin")){ZZ_pX a=product_tree(left,lp);if(!fs::exists(lp.string()+".bin"))write_poly(lp.string()+".bin",a);}
            if(!fs::exists(rp.string()+".bin")){ZZ_pX b=product_tree(right,rp);if(!fs::exists(rp.string()+".bin"))write_poly(rp.string()+".bin",b);}
            disk_crt_mul(result,lp.string()+".bin",rp.string()+".bin");
        }else{ZZ_pX a=product_tree(left,lp),b=product_tree(right,rp);safe_mul(result,a,b);}
    }
    if(deg(result)>=1000000||prefix.filename()=="positive"||prefix.filename()=="negative"){write_poly(checkpoint,result);std::cout<<"Saved "<<checkpoint.filename()<<" degree "<<deg(result)<<" RSS "<<peak_rss()<<std::endl;}
    return result;
}

void build(const fs::path& parameters,const fs::path& directory){
    fs::create_directories(directory);std::ifstream input(parameters);ZZ modulus,constant;long count;input>>modulus>>constant>>count;require(bool(input),"Invalid attack parameters");ZZ_p::init(modulus);
    std::vector<Term> positive,negative;
    for(long i=0;i<count;++i){ZZ offset;long k;input>>offset>>k;require(bool(input),"Truncated attack parameters");if(k>0)positive.push_back({offset,k});if(k<0)negative.push_back({offset,-k});}
    auto order=[](const Term& a,const Term& b){return a.exponent>b.exponent;};std::sort(positive.begin(),positive.end(),order);std::sort(negative.begin(),negative.end(),order);
    if(!fs::exists(directory/"positive.bin")){ZZ_pX p=product_tree(positive,directory/"positive");if(!fs::exists(directory/"positive.bin"))write_poly(directory/"positive.bin",p);}
    if(!fs::exists(directory/"negative.bin")){ZZ_pX p=product_tree(negative,directory/"negative");if(!fs::exists(directory/"negative.bin"))write_poly(directory/"negative.bin",p);}
    auto p=header_of(directory/"positive.bin"),n=header_of(directory/"negative.bin");
    ZZ_pX one,minus;set(one);SetCoeff(minus,0,-conv<ZZ_p>(constant));
    transform_file(directory/"relation.bin",directory/"positive.bin",directory/"negative.bin",one,minus,std::max(p.length,n.length));
    std::cout<<"Relation ready "<<directory/"relation.bin"<<std::endl;
}

void write_state(const fs::path& directory,long stage,const fs::path& f,const fs::path& g){
    std::ofstream state(directory/"state.tmp");state<<stage<<"\n"<<std::quoted(f.string())<<"\n"<<std::quoted(g.string())<<"\n";state.close();fs::rename(directory/"state.tmp",directory/"state.txt");
}

void disk_gcd(fs::path f,fs::path g,const fs::path& directory,long maximum_reduction=1000000,long finish_degree=400000,bool one_stage=false){
    fs::create_directories(directory);long stage=0;
    if(fs::exists(directory/"state.txt")){std::ifstream state(directory/"state.txt");std::string fp,gp;state>>stage>>std::quoted(fp)>>std::quoted(gp);require(bool(state),"Invalid GCD checkpoint");f=fp;g=gp;}
    while(true){
        auto fh=header_of(f),gh=header_of(g);if(fh.length<gh.length){std::swap(f,g);std::swap(fh,gh);}
        long d=fh.length-1,e=gh.length-1;std::cout<<"GCD stage "<<stage<<" degrees "<<d<<" "<<e<<" RSS "<<peak_rss()<<std::endl;
        if(d<=finish_degree||e<0){ZZ_pX a=read_poly(f),b=read_poly(g),h;GCD(h,a,b);write_poly(directory/"gcd.bin",h);std::cout<<"Final GCD degree "<<deg(h)<<std::endl;if(deg(h)==1){ZZ_p root=-coeff(h,0)/coeff(h,1);std::ofstream result(directory/"seed.txt");result<<rep(root)<<"\n";std::cout<<"Seed recovered "<<rep(root)<<std::endl;}return;}
        long reduction=std::min(maximum_reduction,std::max(1L,d/3)),length;
        fs::path prefix=directory/("stage-"+std::to_string(stage));ZZ_pXMatrix matrix;
        fs::path metadata=prefix.string()+"-matrix.txt";
        if(fs::exists(metadata)){
            std::ifstream meta(metadata);long saved_reduction=0;meta>>saved_reduction>>length;require(bool(meta)&&saved_reduction==reduction&&length>0&&length<=long(fh.length),"Invalid matrix checkpoint");
            for(int i=0;i<2;++i)for(int j=0;j<2;++j)matrix(i,j)=read_poly(prefix.string()+"-m"+std::to_string(i)+std::to_string(j)+".bin");
        }else{
            if(d-e>=reduction||d==e){
                long difference=d-e;require(difference<=e,"Initial polynomial degree gap too large");long offset=e-difference;
                ZZ_pX a=read_range(f,offset,2*difference+1),b=read_range(g,offset,difference+1),quotient;div(quotient,a,b);
                clear(matrix(0,0));set(matrix(0,1));set(matrix(1,0));negate(matrix(1,1),quotient);length=e+1;
            }else{
                long offset=d-2*reduction+2;require(offset>=0,"Invalid half-GCD range");
                ZZ_pX a=read_range(f,offset,fh.length-offset),b=read_range(g,offset,gh.length-offset);
                std::cout<<"Half-GCD prefix "<<deg(a)<<" "<<deg(b)<<" reduction "<<reduction<<std::endl;
                XHalfGCD(matrix,a,b,reduction);
                long matrix_degree=-1;for(int i=0;i<2;++i)for(int j=0;j<2;++j)matrix_degree=std::max(matrix_degree,deg(matrix(i,j)));
                length=std::max(offset+std::max(deg(a),deg(b)),offset-1+matrix_degree)+1;
            }
            for(int i=0;i<2;++i)for(int j=0;j<2;++j)write_poly(prefix.string()+"-m"+std::to_string(i)+std::to_string(j)+".bin",matrix(i,j));
            fs::path temporary=metadata.string()+".tmp";std::ofstream meta(temporary);meta<<reduction<<" "<<length<<"\n";meta.close();fs::rename(temporary,metadata);
        }
        fs::path next_f=prefix.string()+"-f.bin",next_g=prefix.string()+"-g.bin";
        auto nf=transform_file(next_f,f,g,matrix(0,0),matrix(0,1),length);
        auto ng=transform_file(next_g,f,g,matrix(1,0),matrix(1,1),length);
        require(nf.length<=fh.length&&ng.length<gh.length,"GCD stage failed to reduce degrees");
        write_state(directory,stage+1,next_f,next_g);
        if(f.parent_path()==directory&&f.filename().string().find("stage-")==0)fs::remove(f);
        if(g.parent_path()==directory&&g.filename().string().find("stage-")==0)fs::remove(g);
        f=next_f;g=next_g;++stage;
        if(one_stage){std::cout<<"Checkpoint complete; release process memory before next stage"<<std::endl;return;}
    }
}

void self_check(const fs::path& directory){
    fs::create_directories(directory);ZZ modulus=power2_ZZ(127)-1;ZZ_p::init(modulus);ZZ_pX a,b,actual,expected;
    random(a,1000);random(b,800);crt_mul(actual,a,b);mul(expected,a,b);require(actual==expected,"CRT self-check failed");
    write_poly(directory/"crt-a.bin",a);write_poly(directory/"crt-b.bin",b);disk_crt_mul(actual,directory/"crt-a.bin",directory/"crt-b.bin");require(actual==expected,"Disk CRT self-check failed");
    ZZ_pX aa,bb;SetCoeff(aa,0,17);SetCoeff(aa,1,1);SetCoeff(bb,0,23);SetCoeff(bb,1,1);
    power(a,aa,1500);power(b,bb,1501);ZZ_p root=conv<ZZ_p>(123456789);SetCoeff(a,0,coeff(a,0)-power(root+17,1500));SetCoeff(b,0,coeff(b,0)-power(root+23,1501));
    write_poly(directory/"a.bin",a);write_poly(directory/"b.bin",b);require(read_poly(directory/"a.bin")==a,"Binary I/O self-check failed");
    disk_gcd(directory/"a.bin",directory/"b.bin",directory/"gcd",100,100,true);
    require(!fs::exists(directory/"gcd/gcd.bin"),"Expected an intermediate checkpoint");
    disk_gcd(directory/"a.bin",directory/"b.bin",directory/"gcd",100,100);
    ZZ_pX h=read_poly(directory/"gcd/gcd.bin");require(deg(h)==1&&coeff(h,0)==-root,"Disk GCD self-check failed");
    std::cout<<"All arithmetic and disk GCD self-checks passed"<<std::endl;
}

int main(int argc,char** argv){
    try{
        require(argc>=2,"Specify selfcheck, build, or gcd");SetNumThreads(8);start_watchdog();std::string mode=argv[1];
        if(mode=="selfcheck"){require(argc==3,"selfcheck directory");self_check(argv[2]);}
        else if(mode=="crtbench"){
            require(argc==4,"crtbench modulus_file degree");std::ifstream in(argv[2]);ZZ modulus;in>>modulus;require(bool(in),"Invalid modulus");ZZ_p::init(modulus);long degree=std::stol(argv[3]);
            ZZ_pX a,b,actual,expected;random(a,degree);random(b,degree);auto begin=std::chrono::steady_clock::now();crt_mul(actual,a,b);mul(expected,a,b);require(actual==expected,"Large CRT self-check failed");
            std::cout<<"Large CRT verified seconds "<<std::chrono::duration<double>(std::chrono::steady_clock::now()-begin).count()<<" RSS "<<peak_rss()<<std::endl;
        }
        else if(mode=="build"){require(argc==4,"build parameters directory");build(argv[2],argv[3]);}
        else if(mode=="gcd"){require(argc==6,"gcd modulus_file first second directory");std::ifstream in(argv[2]);ZZ modulus;in>>modulus;require(bool(in),"Invalid modulus");ZZ_p::init(modulus);disk_gcd(argv[3],argv[4],argv[5],1000000,400000,true);}
        else throw std::runtime_error("Unknown mode");
    }catch(const InvModErrorObject& error){std::cerr<<"FACTOR "<<GCD(error.get_a(),error.get_n())<<std::endl;return 10;}
    catch(const std::exception& error){std::cerr<<"ERROR "<<error.what()<<std::endl;return 1;}
}
