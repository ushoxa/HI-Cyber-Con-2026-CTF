#!/bin/sh
set -eu
cd "$(dirname "$0")"
solver_root="$PWD"
gmp_prefix="${GMP_PREFIX:-/opt/homebrew}"
compiler="${CXX:-clang++}"

if [ ! -f "$solver_root/ntl-local/lib/libntl.a" ]; then
    tar -xzf ntl-11.6.0.tar.gz
    (
        cd ntl-11.6.0/src
        ./configure NTL_GMP_LIP=on GMP_PREFIX="$gmp_prefix" NTL_THREADS=on \
            PREFIX="$solver_root/ntl-local" CXX="$compiler" CXXFLAGS='-O3'
        make -j4
        make install
    )
fi

"$compiler" -O3 -std=c++17 -I"$solver_root/ntl-local/include" \
    -I"$gmp_prefix/include" ntl_attack.cpp -L"$solver_root/ntl-local/lib" \
    -lntl -L"$gmp_prefix/lib" -lgmp -o ntl-attack
mkdir -p work
check_directory="$(mktemp -d "$solver_root/work/selfcheck.XXXXXX")"
./ntl-attack selfcheck "$check_directory"
