#!/usr/bin/env python3
"""Recover the Rocinate Revenge flag using checkpointed native arithmetic."""

import ast
import hashlib
import json
import re
import subprocess
import sys
import zipfile
from pathlib import Path

EXPECTED_SHA256 = '78540bed7e1e9fbe4deb67f710abde453b7fd87116fda6c61360749c735d9101'
HERE = Path(__file__).resolve().parent


def parse_challenge(archive):
    raw = archive.read_bytes()
    if hashlib.sha256(raw).hexdigest() != EXPECTED_SHA256:
        raise ValueError('Archive SHA-256 does not match this challenge')
    with zipfile.ZipFile(archive) as source:
        text = source.read('chall.txt').decode().strip().strip("'").strip()
    match = re.fullmatch(r'(\d+)\s+(\d+)\s+(\d+)\s+(\[.*?\])\s+(\[.*?\])\s+(\[.*?\])', text, re.S)
    if match is None:
        raise ValueError('Unexpected chall.txt format')
    a, b, modulus = map(int, match.group(1, 2, 3))
    products, challenges, commitments = map(ast.literal_eval, match.group(4, 5, 6))
    if not len(products) == len(challenges) == len(commitments) == 100:
        raise ValueError('Expected 100 samples')
    return {'a': a, 'b': b, 'N': modulus, 'Z': products, 'C': challenges, 'T': commitments}


def extended_gcd(a, b):
    old, current = (a, 1, 0), (b, 0, 1)
    while current[0]:
        quotient = old[0] // current[0]
        old, current = current, tuple(x - quotient * y for x, y in zip(old, current))
    return old


def recover_flag(data, seed):
    modulus = data['N']
    masks = []
    nonce = seed
    for product in data['Z']:
        if not nonce or product % nonce:
            raise ValueError('Recovered seed does not divide the published products')
        mask = product // nonce
        if not 0 <= mask < modulus:
            raise ValueError('Invalid recovered mask')
        masks.append(mask)
        nonce = (data['a'] * nonce + data['b']) % modulus
    gcd, result = data['C'][0], masks[0]
    for exponent, mask in zip(data['C'][1:], masks[1:]):
        gcd, u, v = extended_gcd(gcd, exponent)
        result = pow(result, u, modulus) * pow(mask, v, modulus) % modulus
        if gcd == 1:
            break
    if gcd != 1:
        raise ValueError('Challenges do not have GCD 1')
    if not all(pow(result, c, modulus) == mask for c, mask in zip(data['C'], masks)):
        raise ValueError('Flag failed verification against the 100 samples')
    flag = result.to_bytes((result.bit_length() + 7) // 8, 'big')
    if not (flag.startswith(b'hiCTF{') and flag.endswith(b'}')):
        raise ValueError('Recovered residue does not have flag syntax')
    return flag


def prepare(data, directory):
    relations = json.loads((HERE / 'relations.json').read_text())
    modulus = data['N']
    alpha, beta = 1, 0
    offsets, values = [], []
    for product in data['Z']:
        inverse = pow(alpha, -1, modulus)
        offsets.append(beta * inverse % modulus)
        values.append(product * inverse % modulus)
        alpha = alpha * data['a'] % modulus
        beta = (beta * data['a'] + data['b']) % modulus
    for index, relation in enumerate(relations):
        if len(relation) != 100 or sum(k * c for k, c in zip(relation, data['C'])):
            raise ValueError('Invalid precomputed integer relation')
        constant = 1
        for value, exponent in zip(values, relation):
            constant = constant * pow(value, exponent, modulus) % modulus
        lines = [str(modulus), str(constant), '100']
        lines += [f'{offset} {exponent}' for offset, exponent in zip(offsets, relation)]
        (directory / f'parameters-{index}.txt').write_text('\n'.join(lines) + '\n')
    (directory / 'modulus.txt').write_text(str(modulus) + '\n')


def run_native(binary, directory, name, arguments):
    print(name, flush=True)
    with (directory / f'{name}.log').open('a') as log:
        result = subprocess.run([str(binary), *map(str, arguments)], stdout=log, stderr=subprocess.STDOUT)
    if result.returncode:
        raise RuntimeError(f'{name} exited {result.returncode}; checkpoints and log are in {directory}')


def main():
    if len(sys.argv) not in (2, 3):
        raise SystemExit('Usage: python3 solve.py rocinate-revenge.zip [work-directory]')
    data = parse_challenge(Path(sys.argv[1]))
    binary = HERE / 'ntl-attack'
    if not binary.is_file():
        raise SystemExit('Build the arithmetic helper first: sh build.sh')
    directory = Path(sys.argv[2] if len(sys.argv) == 3 else 'work/rocinate-revenge-run').resolve()
    directory.mkdir(parents=True, exist_ok=True)
    prepare(data, directory)
    for index in range(2):
        subdirectory = directory / f'relation-{index}'
        if not (subdirectory / 'relation.bin').exists():
            run_native(binary, directory, f'build-{index}', ['build', directory / f'parameters-{index}.txt', subdirectory])
    # Completed construction subproducts are unnecessary once both relations exist.
    for index in range(2):
        for pattern in ('positive*.bin', 'negative*.bin'):
            for path in (directory / f'relation-{index}').glob(pattern):
                path.unlink()
    while not (directory / 'gcd/gcd.bin').exists():
        run_native(binary, directory, 'gcd', ['gcd', directory / 'modulus.txt', directory / 'relation-0/relation.bin', directory / 'relation-1/relation.bin', directory / 'gcd'])
    seed = int((directory / 'gcd/seed.txt').read_text())
    flag = recover_flag(data, seed)
    (directory / 'verified-flag.txt').write_bytes(flag + b'\n')
    print(flag.decode(), flush=True)


if __name__ == '__main__':
    main()
