# Rocinate Revenge solver

Python entry point: `solve.py`. Python itself uses only the standard library.
Large polynomial arithmetic uses the included C++ helper, NTL, and GMP.

The full challenge run completed successfully. The recovered flag passed all
100 sample checks in both the running solver and this packaged Python verifier.
Synthetic end-to-end recovery, full-coefficient CRT comparisons, and checkpointed
GCD/resume tests also passed.

## Run on macOS ARM64

Requirements: Python 3, a C++17 compiler, and GMP headers/libraries. The tested
GMP prefix is `/opt/homebrew`. NTL 11.6.0 source is bundled unchanged, including
its license files inside the source archive.

```sh
sh build.sh
python3 solve.py /path/to/rocinate-revenge.zip
```

For GMP installed elsewhere:

```sh
GMP_PREFIX=/your/gmp/prefix sh build.sh
```

Plan for 24 GB RAM, roughly 160 GB free disk during construction, and a
multi-hour computation. The helper stops if its peak resident memory exceeds
17 GiB. Its memory accounting targets macOS; adapt `peak_rss()` before running
on Linux, where `ru_maxrss` uses different units.

The default checkpoint directory is `work/rocinate-revenge-run`. An optional
second argument selects another directory. Re-run the same command to resume.
Do not run two solvers against the same checkpoint directory concurrently.

After recovery, `verified-flag.txt` contains the flag. It is checked against all
100 published products and challenges before being printed.

## Attack

Write the hidden LCG states as `r_i = alpha_i*r_0 + beta_i mod N`.
Normalize `t_i = beta_i/alpha_i` and `v_i = Z_i/alpha_i mod N`.

For an integer vector `k` with `sum(k_i*C_i)=0`, the seed `r_0` is a root of

```text
product((X+t_i)^k_i, k_i>0)
  - product(v_i^k_i) * product((X+t_i)^(-k_i), k_i<0)  mod N.
```

Two independent relations give two polynomials with a common seed root.
The bundled, validated BKZ relations avoid repeating lattice reduction. They
produce degrees 23,939,964 and 24,671,009 for the supplied archive.

The helper constructs the polynomials, then reduces them in checkpointed
half-GCD stages. Once the seed is recovered, Python reconstructs each nonce,
divides each unreduced product by its nonce, and applies Bezout coefficients
to the challenge exponents to recover the flag integer. The hidden exponent
`e` is not needed by this attack.
