#pragma once
#include <NTL/ZZ_pX.h>
#include <NTL/lzz_pX.h>
#include <NTL/BasicThreadPool.h>
#include <NTL/FFT.h>
#include <algorithm>
#include <array>
#include <atomic>
#include <cassert>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <string>
#include <thread>
#include <vector>
#include <sys/resource.h>
#include <gmp.h>
using namespace NTL;
namespace fs=std::filesystem;

inline void require(bool condition,const std::string& message){if(!condition)throw std::runtime_error(message);}
inline long peak_rss(){rusage u{};getrusage(RUSAGE_SELF,&u);return u.ru_maxrss;}
inline void start_watchdog(){std::thread([]{while(true){if(peak_rss()>17LL*1024*1024*1024){std::cerr<<"Memory limit reached; checkpoints preserved"<<std::endl;std::_Exit(99);}std::this_thread::sleep_for(std::chrono::seconds(1));}}).detach();}

// Reconstruct modulo N after each FFT prime, keeping only one prime's FFT in RAM.
template<class Fill> void crt_core(ZZ_pX& result,long a_length,long b_length,const std::array<ZZ,2>& expected,Fill fill){
    if(a_length==0||b_length==0){clear(result);return;}
    const ZZ modulus=ZZ_p::modulus();
    const long length=a_length+b_length-1;
    const ZZ bound=4*std::min(a_length,b_length)*sqr(modulus-1);
    std::vector<long> primes;ZZ product(1);
    for(long i=0;product<=bound;++i){UseFFTPrime(i);long q=GetFFTPrime(i);require(CalcMaxRoot(q)>=NextPowerOfTwo(length),"FFT prime too small");primes.push_back(q);product*=q;}
    result.rep.SetLength(length);
    for(long i=0;i<length;++i)clear(result.rep[i]);
    std::vector<double> sums(length,0.0);
    std::cout<<"CRT multiplication degree "<<length-1<<" primes "<<primes.size()<<std::endl;
    for(long index=0;index<long(primes.size());++index){
        long q=primes[index];zz_p::FFTInit(index);
        zz_pX aa,bb,cc;fill(aa,bb,q);
        aa.normalize();bb.normalize();mul(cc,aa,bb);aa.kill();bb.kill();
        ZZ quotient=product/q,coefficient=quotient%modulus;
        long inverse=InvMod(rem(quotient,q),q);auto precondition=PrepMulModPrecon(inverse,q);
        const double reciprocal=1.0/double(q);
        NTL_EXEC_RANGE(length,first,last)
            ZZ temporary;
            for(long i=first;i<last;++i){
                long residue=i<cc.rep.length()?rep(cc.rep[i]):0;
                long u=MulModPrecon(residue,inverse,q,precondition);
                sums[i]+=double(u)*reciprocal;
                mul(temporary,coefficient,u);add(temporary,temporary,rep(result.rep[i]));
                rem(result.rep[i].LoopHole(),temporary,modulus);
            }
        NTL_EXEC_RANGE_END
        if((index+1)%10==0||index+1==long(primes.size()))std::cout<<"CRT prime "<<index+1<<"/"<<primes.size()<<" RSS "<<peak_rss()<<std::endl;
    }
    const ZZ product_mod=product%modulus;
    NTL_EXEC_RANGE(length,first,last)
        ZZ temporary;
        for(long i=first;i<last;++i){
            temporary=rep(result.rep[i]);MulSubFrom(temporary,product_mod,long(std::floor(sums[i]+0.5)));
            rem(result.rep[i].LoopHole(),temporary,modulus);
        }
    NTL_EXEC_RANGE_END
    result.normalize();
    for(int k=0;k<2;++k)require(rep(eval(result,conv<ZZ_p>(k+2)))==expected[k],"CRT multiplication check failed");
}
inline void crt_mul(ZZ_pX& result,const ZZ_pX& a,const ZZ_pX& b){
    std::array<ZZ,2> expected;for(int k=0;k<2;++k){ZZ_p x=conv<ZZ_p>(k+2);expected[k]=rep(eval(a,x)*eval(b,x));}
    crt_core(result,a.rep.length(),b.rep.length(),expected,[&](zz_pX& aa,zz_pX& bb,long){
        const auto& reduction=zz_p::ZZ_red_struct();aa.rep.SetLength(a.rep.length());bb.rep.SetLength(b.rep.length());
        NTL_EXEC_RANGE(a.rep.length(),first,last)
            for(long i=first;i<last;++i)aa.rep[i].LoopHole()=reduction.rem(rep(a.rep[i]));
        NTL_EXEC_RANGE_END
        NTL_EXEC_RANGE(b.rep.length(),first,last)
            for(long i=first;i<last;++i)bb.rep[i].LoopHole()=reduction.rem(rep(b.rep[i]));
        NTL_EXEC_RANGE_END
    });
}

inline void safe_mul(ZZ_pX& result,const ZZ_pX& a,const ZZ_pX& b){
    if(deg(a)+deg(b)<=2000000)mul(result,a,b);else crt_mul(result,a,b);
}
inline ZZ_pX safe_power(const ZZ_pX& a,long exponent){
    ZZ_pX result,base=a;set(result);
    while(exponent){if(exponent&1){ZZ_pX t;safe_mul(t,result,base);swap(result,t);}exponent>>=1;if(exponent){ZZ_pX t;safe_mul(t,base,base);swap(base,t);}}
    return result;
}

constexpr uint64_t FILE_MAGIC=0x726f63706f6c7931ULL;
struct PolyHeader {uint64_t width=0,length=0;ZZ modulus;std::array<ZZ,2> evaluation;};
inline void write_bytes(std::ostream& out,const ZZ& value,long width){std::vector<unsigned char> bytes(width);BytesFromZZ(bytes.data(),value,width);out.write(reinterpret_cast<char*>(bytes.data()),width);}
inline ZZ read_bytes(std::istream& in,long width){std::vector<unsigned char> bytes(width);in.read(reinterpret_cast<char*>(bytes.data()),width);require(bool(in),"Truncated polynomial file");ZZ z;ZZFromBytes(z,bytes.data(),width);return z;}
inline PolyHeader read_header(std::istream& input){
    uint64_t magic;PolyHeader header;input.read(reinterpret_cast<char*>(&magic),8);input.read(reinterpret_cast<char*>(&header.width),8);input.read(reinterpret_cast<char*>(&header.length),8);
    require(bool(input)&&magic==FILE_MAGIC&&header.width>0&&header.width<=1024,"Invalid polynomial header");
    header.modulus=read_bytes(input,header.width);for(auto& x:header.evaluation)x=read_bytes(input,header.width);
    require(header.modulus==ZZ_p::modulus(),"Polynomial modulus mismatch");return header;
}
inline PolyHeader header_of(const fs::path& file){std::ifstream in(file,std::ios::binary);require(bool(in),"Cannot open "+file.string());return read_header(in);}
inline ZZ_pX read_range(const fs::path& file,long offset,long count){
    std::ifstream in(file,std::ios::binary);require(bool(in),"Cannot open "+file.string());auto h=read_header(in);
    ZZ_pX result;if(offset>=long(h.length)||count<=0)return result;count=std::min(count,long(h.length)-offset);
    in.seekg(24+3*h.width+uint64_t(offset)*h.width);result.rep.SetLength(count);
    constexpr long CHUNK=4096;std::vector<unsigned char> bytes(CHUNK*h.width);
    for(long start=0;start<count;start+=CHUNK){long n=std::min(CHUNK,count-start);in.read(reinterpret_cast<char*>(bytes.data()),n*h.width);require(bool(in),"Truncated polynomial coefficients");for(long j=0;j<n;++j)ZZFromBytes(result.rep[start+j].LoopHole(),bytes.data()+j*h.width,h.width);}
    result.normalize();return result;
}
inline ZZ_pX read_poly(const fs::path& file){auto h=header_of(file);return read_range(file,0,h.length);}

class PolyWriter {
    fs::path target,temporary;std::ofstream output;PolyHeader header;long position=0,last_nonzero=-1;std::array<ZZ_p,2> powers{conv<ZZ_p>(1),conv<ZZ_p>(1)},evaluations{conv<ZZ_p>(0),conv<ZZ_p>(0)};
public:
    explicit PolyWriter(const fs::path& file):target(file),temporary(file.string()+".tmp"),output(temporary,std::ios::binary){
        require(bool(output),"Cannot create "+temporary.string());header.modulus=ZZ_p::modulus();header.width=NumBytes(header.modulus);
        uint64_t magic=FILE_MAGIC;output.write(reinterpret_cast<char*>(&magic),8);output.write(reinterpret_cast<char*>(&header.width),8);uint64_t zero=0;output.write(reinterpret_cast<char*>(&zero),8);write_bytes(output,header.modulus,header.width);write_bytes(output,ZZ(0),header.width);write_bytes(output,ZZ(0),header.width);
    }
    void append(const ZZ_pX& block,long count){
        require(deg(block)<count,"Polynomial block too large");
        if(!IsZero(block))last_nonzero=position+deg(block);
        for(int k=0;k<2;++k){ZZ_p point=conv<ZZ_p>(k+2);evaluations[k]+=eval(block,point)*powers[k];powers[k]*=power(point,count);}
        constexpr long CHUNK=4096;std::vector<unsigned char> bytes(CHUNK*header.width);
        for(long start=0;start<count;start+=CHUNK){long n=std::min(CHUNK,count-start);std::fill(bytes.begin(),bytes.begin()+n*header.width,0);for(long j=0;j<n&&start+j<block.rep.length();++j)BytesFromZZ(bytes.data()+j*header.width,rep(block.rep[start+j]),header.width);output.write(reinterpret_cast<char*>(bytes.data()),n*header.width);require(bool(output),"Polynomial write failed");}
        position+=count;
    }
    PolyHeader finish(){
        header.length=last_nonzero+1;for(int k=0;k<2;++k)header.evaluation[k]=rep(evaluations[k]);
        output.seekp(16);output.write(reinterpret_cast<char*>(&header.length),8);output.seekp(24+header.width);for(auto& x:header.evaluation)write_bytes(output,x,header.width);output.close();
        fs::resize_file(temporary,24+3*header.width+header.length*header.width);fs::rename(temporary,target);return header;
    }
};
inline PolyHeader write_poly(const fs::path& file,const ZZ_pX& polynomial){PolyWriter writer(file);writer.append(polynomial,std::max(1L,polynomial.rep.length()));return writer.finish();}

inline void read_small_prime(const fs::path& file,zz_pX& result,long prime){
    std::ifstream input(file,std::ios::binary);require(bool(input),"Cannot open "+file.string());auto h=read_header(input);result.rep.SetLength(h.length);
    constexpr long CHUNK=65536;std::vector<unsigned char> bytes(CHUNK*h.width);
    for(long start=0;start<long(h.length);start+=CHUNK){
        long count=std::min(CHUNK,long(h.length)-start);input.read(reinterpret_cast<char*>(bytes.data()),count*h.width);require(bool(input),"Truncated CRT input");
        NTL_EXEC_RANGE(count,first,last)
            ZZ temporary;
            for(long j=first;j<last;++j){
                long value;
                if(h.width%sizeof(mp_limb_t)==0)value=mpn_mod_1(reinterpret_cast<const mp_limb_t*>(bytes.data()+j*h.width),h.width/sizeof(mp_limb_t),prime);
                else{ZZFromBytes(temporary,bytes.data()+j*h.width,h.width);value=rem(temporary,prime);}
                result.rep[start+j].LoopHole()=value;
            }
        NTL_EXEC_RANGE_END
    }
    result.normalize();
}
inline void disk_crt_mul(ZZ_pX& result,const fs::path& a,const fs::path& b){
    auto ah=header_of(a),bh=header_of(b);std::array<ZZ,2> expected;
    for(int k=0;k<2;++k)expected[k]=MulMod(ah.evaluation[k],bh.evaluation[k],ZZ_p::modulus());
    crt_core(result,ah.length,bh.length,expected,[&](zz_pX& aa,zz_pX& bb,long q){read_small_prime(a,aa,q);read_small_prime(b,bb,q);});
}

inline PolyHeader transform_file(const fs::path& output,const fs::path& f,const fs::path& g,const ZZ_pX& a,const ZZ_pX& b,long length,long block_size=1000000){
    auto fh=header_of(f),gh=header_of(g);PolyWriter writer(output);ZZ_pX carry;
    for(long offset=0;offset<length;offset+=block_size){
        long count=std::min(block_size,length-offset);ZZ_pX ff=read_range(f,offset,count),gg=read_range(g,offset,count),left,right,sum,chunk;
        safe_mul(left,a,ff);ff.kill();safe_mul(right,b,gg);gg.kill();add(sum,left,right);left.kill();right.kill();add(sum,sum,carry);carry.kill();
        trunc(chunk,sum,count);RightShift(carry,sum,count);sum.kill();writer.append(chunk,count);
        std::cout<<"Transform "<<output.filename()<<" "<<offset+count<<"/"<<length<<std::endl;
    }
    auto result=writer.finish();
    for(int k=0;k<2;++k){ZZ_p point=conv<ZZ_p>(k+2);ZZ_p expected=eval(a,point)*conv<ZZ_p>(fh.evaluation[k])+eval(b,point)*conv<ZZ_p>(gh.evaluation[k]);require(rep(expected)==result.evaluation[k],"Streamed transform check failed");}
    return result;
}
